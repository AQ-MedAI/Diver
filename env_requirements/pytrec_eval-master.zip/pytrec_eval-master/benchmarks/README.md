pytrec_eval benchmarks
======================

This directory contains the scripts used to generate the benchmark experiments in the SIGIR'18 short paper:

	Christophe Van Gysel and Maarten de Rijke. 2018. Pytrec_eval: An Extremely Fast Python Interface to trec_eval. In Proceedings of SIGIR 2018.